package com.info.settlespot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SettlespotApplication {

	public static void main(String[] args) {
		SpringApplication.run(SettlespotApplication.class, args);
	}

}
