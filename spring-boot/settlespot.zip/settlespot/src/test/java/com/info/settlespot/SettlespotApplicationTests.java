package com.info.settlespot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SettlespotApplicationTests {

	@Test
	void contextLoads() {
	}

}
