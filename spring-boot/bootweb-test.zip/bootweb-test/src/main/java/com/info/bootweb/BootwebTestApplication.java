package com.info.bootweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootwebTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootwebTestApplication.class, args);
	}

}
