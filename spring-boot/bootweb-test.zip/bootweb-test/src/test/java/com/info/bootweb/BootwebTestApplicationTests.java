package com.info.bootweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootwebTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
