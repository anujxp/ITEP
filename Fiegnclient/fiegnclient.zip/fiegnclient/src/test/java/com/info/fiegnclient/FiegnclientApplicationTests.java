package com.info.fiegnclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiegnclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
