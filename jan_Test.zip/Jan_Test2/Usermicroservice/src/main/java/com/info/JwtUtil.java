package com.info;

import java.util.Date;
import java.util.Map;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
	private final String SECRETKEY = "abcdefzhijklmnopqrstuvwxyzdjfkdjfkjifenfie";
	
	 public String generateToken(UserDetails user) {
		  
		  String role = user.getAuthorities()
	              .iterator()
	              .next()
	              .getAuthority(); 
		  
		  String token = Jwts.builder()
		  .setSubject(user.getUsername())
		  .setClaims(Map.of("role",role))
		  .setIssuedAt(new Date())
		  .setExpiration(new Date(System.currentTimeMillis()+60*60*1000))
		  .signWith(Keys.hmacShaKeyFor(SECRETKEY.getBytes()), SignatureAlgorithm.HS256)
		  .compact();
		  return token;  
	  }
}
