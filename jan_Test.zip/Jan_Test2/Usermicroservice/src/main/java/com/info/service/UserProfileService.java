package com.info.service;

import org.springframework.stereotype.Service;

import com.info.dto.UserProfileDto;
import com.info.entity.User;
import com.info.entity.UserProfile;
import com.info.exception.UserNotFoundException;
import com.info.exception.UserProfileNotFoundException;
import com.info.repo.UserProfileRepo;
import com.info.repo.UserRepo;

@Service
public class UserProfileService {
	private UserProfileRepo repo;
	private UserRepo userRepo;
	public UserProfileService(UserProfileRepo repo, UserRepo userRepo) {
		this.repo = repo;
		this.userRepo = userRepo;
	}
	
	public String create(UserProfileDto dto) {
		System.out.println(dto.getUser_id());
		User user = userRepo.findById(dto.getUser_id()).orElseThrow(()-> new UserNotFoundException("user not found with id " + dto.getUser_id()));
		UserProfile userProfile = new UserProfile();
		userProfile.setBio(dto.getBio());
		userProfile.setFollowers(dto.getFollowers());
		userProfile.setFollowing(dto.getFollowing());
		userProfile.setUsername(dto.getUsername());
		userProfile.setUser(user);
		
		repo.save(userProfile);
		return "Profile Created Successfully";
	}
	
	
	public UserProfileDto viewProfile(int user_id) {
		UserProfile dbProfile = repo.getByUserId(user_id).orElseThrow(()-> new UserProfileNotFoundException("profile not found for user id "+ user_id));
		
		UserProfileDto dto = new UserProfileDto();
		dto.setId(dbProfile.getId());
		dto.setUser_id(dbProfile.getUser().getId());
		dto.setUsername(dbProfile.getUsername());
		dto.setFollowers(dbProfile.getFollowers());
		dto.setFollowing(dbProfile.getFollowing());
		dto.setBio(dbProfile.getBio());
		return dto;
	}
	
	
	public String updateProfile(UserProfileDto dto) {
		UserProfile dbProfile = repo.getByUserId(dto.getUser_id()).orElseThrow(()-> new UserProfileNotFoundException("profile not found for user id "+ dto.getUser_id()));
		
		dbProfile.setUsername(dto.getUsername());
		dbProfile.setFollowers(dto.getFollowers());
		dbProfile.setFollowing(dto.getFollowing());
		dbProfile.setBio(dto.getBio());
		
		repo.save(dbProfile);
		
		return "profile updated successfully";
		
	}
}
