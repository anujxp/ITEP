
package com.info;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import com.info.JwtUtil;

import io.jsonwebtoken.Claims;
import reactor.core.publisher.Mono;

@Component
public class JwtAuthFilter implements GlobalFilter, Ordered {

	 private final JwtUtil jwt;
		public JwtAuthFilter(JwtUtil jwt) {
			this.jwt = jwt;
		}
		@Override
		public int getOrder() {
			return -1;
		}

		@Override
		public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
			ServerHttpRequest request =  exchange.getRequest();
			String requestedRoute =  request.getURI().getPath();
			
			if(requestedRoute.startsWith("/user/login") || requestedRoute.startsWith("/user/register"))
				return chain.filter(exchange);
			
			if(!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION))
			  unauthorized(exchange, "Authorization header is missing");
			
			String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
			System.out.println(authHeader);
			if(authHeader == null || !authHeader.startsWith("Bearer "))
			   return unauthorized(exchange,"Invalid Authorization Header");
			
			String token =  authHeader.substring(7);
			try {
				jwt.validateToken(token);
			}
			catch(Exception e) {
			 return	unauthorized(exchange, "Invalid Jwt Token");
			}
			return chain.filter(exchange);
		}
	    public Mono<Void> unauthorized(ServerWebExchange exchange, String message){
		   exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
		   return exchange.getResponse().setComplete();
		}
		
}
